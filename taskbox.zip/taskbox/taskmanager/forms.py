from django import forms
from .models import Taskbox
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm, UsernameField

from django.contrib.auth.models import User


class TaskForm(forms.ModelForm):
    class Meta:
        model=Taskbox
        fields=['title','description']
        widgets={
            'title':forms.TextInput(attrs={'class':'form-control','style':'margin-bottom:5px;margin-top:5px'}),
            'description':forms.Textarea(attrs={'class':'form-control','style':'resize:none;margin-top:5px','rows':6}),
        }

class RegistrationForm(UserCreationForm):
    username=forms.CharField(widget=forms.TextInput(attrs={'autofocus':'true','class':'form-control username'}))
    email=forms.EmailField(widget=forms.EmailInput(attrs={'class':'form-control email'}))
    password1=forms.CharField(label='password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password2=forms.CharField(label='confirm password',widget=forms.PasswordInput(attrs={'class':'form-control'}))

    class Meta:
        model=User
        fields=['username','email','password1','password2']
    

class loginForm(AuthenticationForm):
    username=UsernameField(widget=forms.TextInput(attrs={'autofocus':'true','class':'form-control'}))
    password=forms.CharField(label='password',widget=forms.PasswordInput(attrs={'class':'form-control'}))
