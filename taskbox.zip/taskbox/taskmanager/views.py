from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect, render
from django.views import View
from .forms import TaskForm, RegistrationForm, loginForm
from .models import Taskbox
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login



from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_decode,urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import EmailMessage

# Create your views here.

def Register(request):
    if request.method=='POST':
        form=RegistrationForm(request.POST)
        if form.is_valid():
            username=form.cleaned_data['username']
            email=form.cleaned_data['email']
            password1=form.cleaned_data['password1']
            password2=form.cleaned_data['password2']
            user=User.objects.create_user(username=username,email=email,password=password1)
            user.is_active=False
            user.save()
            current_site=get_current_site(request)
            mail_subject='please activate your account'
            message=render_to_string('account_verification_email.html',{
                'user':user,
                'domain':current_site,
                'uid':urlsafe_base64_encode(force_bytes(user.pk)),
                'token':default_token_generator.make_token(user),
            })
            to_email=email
            send_email=EmailMessage(mail_subject,message,to=[to_email])
            send_email.send()
            return redirect('/login/?command=verification&email='+email)
        return redirect('register')
    else:
        form=RegistrationForm()
    return render(request,'register.html',{'form':form})

def activate(request,uidb64,token):
    try:
        uid=urlsafe_base64_decode(uidb64).decode()
        user=User._default_manager.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user=None
    if user is not None and default_token_generator.check_token(user,token):
        user.is_active=True
        user.save()
        messages.success(request,'congratulations! your account is activated')
        return redirect('login')
    else:
        messages.error(request,'invalid activation link')
        return redirect('register')


class LoginView(View):
    def get(self,request):
        form=loginForm()
        return render(request,'login.html',locals())
    def post(self,request):
        if request.method=='POST':
            user=request.POST.get('username')
            username=user.lower()
            password=request.POST.get('password')
            user=authenticate(request,username=username,password=password)
            if user is not None:
                login(request,user)
                return redirect('home')
            else:
                messages.warning(request,'Please activate email or enter correct password')
                return redirect('login')
        return redirect('login')


def Login(request):

    return render(request,'login.html')

def home(request):
    tasks=Taskbox.objects.filter(user=request.user)
    return render(request,'home.html',{'tasks':tasks})

def addTask(request,id=0):
    if request.method=='GET':
        if id==0:
            form=TaskForm()
        else:
            task=Taskbox.objects.get(pk=id)
            form=TaskForm(instance=task)
        return render(request,'addtask.html',{'form':form})
    else:
        user=request.user
        if id==0:
            title=request.POST.get('title')
            desc=request.POST.get('description')
            form=Taskbox(user=user,title=title,description=desc)
            form.save()
        else:
            task=Taskbox.objects.get(pk=id)
            title=request.POST.get('title')
            desc=request.POST.get('description')
            task.title=title
            task.description=desc
            task.save()
        return redirect('home')
    
def delete(request,id):
    task=Taskbox.objects.get(pk=id)
    task.delete()
    return redirect('home')