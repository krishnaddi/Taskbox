from django.urls import path, include
from taskmanager import views


urlpatterns=[
    path('',views.Register,name='register'),
    path('home',views.home,name='home'),
    path('addtask',views.addTask,name='addtask'),
    path('<int:id>',views.addTask,name='update'),
    path('delete/<int:id>',views.delete,name='delete'),
    path('activate/<uidb64>/<token>/',views.activate,name='activate'),
    path('login/',views.LoginView.as_view(),name='login'),

]